  <div id="footer">

                    <div class="panel">

<!--                        <div class="panel-holder">

                            <div id="newsletter-subscribe-3" class="box customclass subscribe-box"><h4>Coupons in Your Inbox!</h4>		<div class="subscribe-holder">

                                    <div class="text-box"><p>Receive coupons by email, subscribe now!</p></div>

                                    <form method="post" action="#" class="subscribe-form">
                                        <fieldset>
                                            <div class="row">
                                                <div class="text"><input name="email" class="text" value="" placeholder="Enter Email Address" type="text"></div>
                                            </div>
                                            <div class="row">
                                                <button name="submit" value="Submit" id="submit" title="Subscribe" type="submit" class="btn-submit"><span>Subscribe</span></button>
                                            </div>
                                        </fieldset>

                                        <input name="" value="" type="hidden">
                                        <input name="" value="" type="hidden">
                                        <input name="" value="" type="hidden">
                                        <input name="" value="" type="hidden">
                                        <input name="" value="" type="hidden">
                                        <input name="" value="" type="hidden">

                                    </form>
                                </div>
                            </div><div id="twitter-2" class="box customclass widget_twitter"><div><h4><span class="twitterwidget twitterwidget-title">Follow Us</span></h4><div class="twitter-avatar"><a href="http://twitter.com/themebound" title="Themebound" target="_blank"><img alt="Themebound" src="https://pbs.twimg.com/profile_images/2165760034/logo_normal.jpg"></a></div><ul><li><span class="entry-content">NEW! Block downvoting verified <a href="http://twitter.com/search?q=%23deal" class="twitter-hashtag" target="_blank">#deal</a> / <a href="http://twitter.com/search?q=%23offer" class="twitter-hashtag" target="_blank">#offer</a> / <a href="http://twitter.com/search?q=%23coupon" class="twitter-hashtag" target="_blank">#coupon</a> on Clipper <a href="http://twitter.com/search?q=%23discount" class="twitter-hashtag" target="_blank">#discount</a> theme! <a href="http://twitter.com/search?q=%23wordpress" class="twitter-hashtag" target="_blank">#wordpress</a> <a href="http://t.co/VL3MMhPIpa" target="_blank">http://t.co/VL3MMhPIpa</a></span> <span class="entry-meta"><span class="time-meta"><a href="http://twitter.com/themebound/statuses/638392629923852288" target="_blank">10:17:18 PM August 31, 2015</a></span> <span class="from-meta">from <a href="http://www.facebook.com/twitter" rel="nofollow">Facebook</a></span></span> <span class="intent-meta"><a href="http://twitter.com/intent/tweet?in_reply_to=638392629923852288" data-lang="en" class="in-reply-to" title="Reply" target="_blank">Reply</a><a href="http://twitter.com/intent/retweet?tweet_id=638392629923852288" data-lang="en" class="retweet" title="Retweet" target="_blank">Retweet</a><a href="http://twitter.com/intent/favorite?tweet_id=638392629923852288" data-lang="en" class="favorite" title="Favorite" target="_blank">Favorite</a></span></li><li><span class="entry-content">FlatRoller <a href="http://twitter.com/search?q=%23job" class="twitter-hashtag" target="_blank">#job</a> listing child theme updated to 1.1.1 and is now compatible with <a href="http://twitter.com/search?q=%23WordPress" class="twitter-hashtag" target="_blank">#WordPress</a> 4.3 and JobRoller 1.8.2! <a href="http://t.co/HzNzwO6Z4H" target="_blank">http://t.co/HzNzwO6Z4H</a></span> <span class="entry-meta"><span class="time-meta"><a href="http://twitter.com/themebound/statuses/636847573735575552" target="_blank">03:57:48 PM August 27, 2015</a></span> <span class="from-meta">from <a href="http://www.facebook.com/twitter" rel="nofollow">Facebook</a></span></span> <span class="intent-meta"><a href="http://twitter.com/intent/tweet?in_reply_to=636847573735575552" data-lang="en" class="in-reply-to" title="Reply" target="_blank">Reply</a><a href="http://twitter.com/intent/retweet?tweet_id=636847573735575552" data-lang="en" class="retweet" title="Retweet" target="_blank">Retweet</a><a href="http://twitter.com/intent/favorite?tweet_id=636847573735575552" data-lang="en" class="favorite" title="Favorite" target="_blank">Favorite</a></span></li><li><span class="entry-content">FlatPage <a href="http://twitter.com/search?q=%23directory" class="twitter-hashtag" target="_blank">#directory</a> child theme updated to 1.0.6 and is now compatible with <a href="http://twitter.com/search?q=%23WordPress" class="twitter-hashtag" target="_blank">#WordPress</a> 4.3 and Vantage 3.0.3! <a href="http://t.co/8ZDXNVW7j9" target="_blank">http://t.co/8ZDXNVW7j9</a></span> <span class="entry-meta"><span class="time-meta"><a href="http://twitter.com/themebound/statuses/636817612572258304" target="_blank">01:58:44 PM August 27, 2015</a></span> <span class="from-meta">from <a href="http://www.facebook.com/twitter" rel="nofollow">Facebook</a></span></span> <span class="intent-meta"><a href="http://twitter.com/intent/tweet?in_reply_to=636817612572258304" data-lang="en" class="in-reply-to" title="Reply" target="_blank">Reply</a><a href="http://twitter.com/intent/retweet?tweet_id=636817612572258304" data-lang="en" class="retweet" title="Retweet" target="_blank">Retweet</a><a href="http://twitter.com/intent/favorite?tweet_id=636817612572258304" data-lang="en" class="favorite" title="Favorite" target="_blank">Favorite</a></span></li></ul><div class="follow-button"><a href="http://twitter.com/themebound" class="twitter-follow-button" title="Follow @themebound" data-lang="en" target="_blank">@themebound</a></div></div></div><div id="custom-coupons-3" class="box cut widget-custom-coupons"><h4>Popular Coupons</h4><div class="coupon-ticker"><ul class="list"><li><a href="http://demos.themebound.com/flatter/coupons/exclusive-august-offer-for-all-members/">Exclusive August Offer for all members</a> - 4 comments</li>
                                        <li><a href="http://demos.themebound.com/flatter/coupons/offer-of-the-day/">Offer Of the day</a> - 3 comments</li>
                                        <li><a href="http://demos.themebound.com/flatter/coupons/multi-user-plugin/">Multi User Plugin</a> - 3 comments</li>
                                        <li><a href="http://demos.themebound.com/flatter/coupons/books-50-off-or-more/">Books 50 off or more</a> - 0 comments</li>
                                        <li><a href="http://demos.themebound.com/flatter/coupons/best-coupon/">Best Coupon</a> - 0 comments</li>
                                    </ul></div></div>
                        </div>  panel-holder -->

                    </div> <!-- panel -->

                    <div class="bar">

                        <div class="bar-holder">

                            <ul id="menu-footer" class="menu"><li id="menu-item-26" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-26"><a href="<?php echo base_url(); ?>discounts">Home</a></li>
                               
                            </ul>			<p>Copyright © 2017 | <a target="_blank" href="<?php echo base_url(); ?>discounts" title="Hereyago">Hereyago.com</a> | Powered by <a target="_blank" href="http://www.itideology.com/" title="IT Ideology">IT Ideology</a></p>

                        </div>

                    </div>

                </div>