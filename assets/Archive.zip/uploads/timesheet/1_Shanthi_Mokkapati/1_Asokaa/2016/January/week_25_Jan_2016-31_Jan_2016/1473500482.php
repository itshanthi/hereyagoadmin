//for day_1
                if ($v_l_msg['timesheet']['day_1'] == 'NULL' || $v_l_msg['timesheet']['day_1'] == '0') {
                    $day_1 = $this->input->post('day_1');
                } else {
                    $day_1 = $v_l_msg['timesheet']['day_1'];
                }
                //for day_2
                if ($v_l_msg['timesheet']['day_2'] == 'NULL' || $v_l_msg['timesheet']['day_2'] == '0') {
                    $day_2 = $this->input->post('day_2');
                } else {
                    $day_2 = $v_l_msg['timesheet']['day_2'];
                }
                //for day_3
                if ($v_l_msg['timesheet']['day_3'] == 'NULL' || $v_l_msg['timesheet']['day_3'] == '0') {
                    $day_3 = $this->input->post('day_3');
                } else {
                    $day_3 = $v_l_msg['timesheet']['day_3'];
                }
                //for day_4
                if ($v_l_msg['timesheet']['day_4'] == 'NULL' || $v_l_msg['timesheet']['day_4'] == '0') {
                    $day_4 = $this->input->post('day_4');
                } else {
                    $day_4 = $v_l_msg['timesheet']['day_4'];
                }
                 //for day_5
                if ($v_l_msg['timesheet']['day_5'] == 'NULL' || $v_l_msg['timesheet']['day_5'] == '0') {
                    $day_5 = $this->input->post('day_5');
                } else {
                    $day_5 = $v_l_msg['timesheet']['day_5'];
                }
                //for day_6
                if ($v_l_msg['timesheet']['day_6'] == 'NULL' || $v_l_msg['timesheet']['day_6'] == '0') {
                    $day_6 = $this->input->post('day_6');
                } else {
                    $day_6 = $v_l_msg['timesheet']['day_6'];
                }
                //for day_7
                if ($v_l_msg['timesheet']['day_7'] == 'NULL' || $v_l_msg['timesheet']['day_7'] == '0') {
                    $day_7 = $this->input->post('day_7');
                } else {
                    $day_7 = $v_l_msg['timesheet']['day_7'];
                }
                 //for day_8
                if ($v_l_msg['timesheet']['day_8'] == 'NULL' || $v_l_msg['timesheet']['day_8'] == '0') {
                    $day_8 = $this->input->post('day_8');
                } else {
                    $day_8 = $v_l_msg['timesheet']['day_8'];
                }
                 //for day_9
                if ($v_l_msg['timesheet']['day_9'] == 'NULL' || $v_l_msg['timesheet']['day_9'] == '0') {
                    $day_9 = $this->input->post('day_9');
                } else {
                    $day_9 = $v_l_msg['timesheet']['day_9'];
                }
                 //for day_10
                if ($v_l_msg['timesheet']['day_10'] == 'NULL' || $v_l_msg['timesheet']['day_10'] == '0') {
                    $day_10 = $this->input->post('day_10');
                } else {
                    $day_10 = $v_l_msg['timesheet']['day_10'];
                }
                //for day_11
                if ($v_l_msg['timesheet']['day_11'] == 'NULL' || $v_l_msg['timesheet']['day_11'] == '0') {
                    $day_11 = $this->input->post('day_11');
                } else {
                    $day_11 = $v_l_msg['timesheet']['day_11'];
                }
                //for day_12
                if ($v_l_msg['timesheet']['day_12'] == 'NULL' || $v_l_msg['timesheet']['day_12'] == '0') {
                    $day_12 = $this->input->post('day_12');
                } else {
                    $day_12 = $v_l_msg['timesheet']['day_12'];
                }
                //for day_13
                if ($v_l_msg['timesheet']['day_13'] == 'NULL' || $v_l_msg['timesheet']['day_13'] == '0') {
                    $day_13 = $this->input->post('day_13');
                } else {
                    $day_13 = $v_l_msg['timesheet']['day_13'];
                }
                //for day_14
                if ($v_l_msg['timesheet']['day_14'] == 'NULL' || $v_l_msg['timesheet']['day_14'] == '0') {
                    $day_14 = $this->input->post('day_14');
                } else {
                    $day_14 = $v_l_msg['timesheet']['day_14'];
                }
                //for day_15
                if ($v_l_msg['timesheet']['day_15'] == 'NULL' || $v_l_msg['timesheet']['day_15'] == '0') {
                    $day_15 = $this->input->post('day_15');
                } else {
                    $day_15 = $v_l_msg['timesheet']['day_15'];
                }
                //for day_16
                if ($v_l_msg['timesheet']['day_16'] == 'NULL' || $v_l_msg['timesheet']['day_16'] == '0') {
                    $day_16 = $this->input->post('day_16');
                } else {
                    $day_16 = $v_l_msg['timesheet']['day_16'];
                }
                //for day_17
                if ($v_l_msg['timesheet']['day_17'] == 'NULL' || $v_l_msg['timesheet']['day_17'] == '0') {
                    $day_17 = $this->input->post('day_17');
                } else {
                    $day_17 = $v_l_msg['timesheet']['day_17'];
                }
                 //for day_18
                if ($v_l_msg['timesheet']['day_18'] == 'NULL' || $v_l_msg['timesheet']['day_18'] == '0') {
                    $day_18 = $this->input->post('day_18');
                } else {
                    $day_18 = $v_l_msg['timesheet']['day_18'];
                }
                 //for day_19
                if ($v_l_msg['timesheet']['day_19'] == 'NULL' || $v_l_msg['timesheet']['day_19'] == '0') {
                    $day_19 = $this->input->post('day_19');
                } else {
                    $day_19 = $v_l_msg['timesheet']['day_19'];
                }
                 //for day_20
                if ($v_l_msg['timesheet']['day_20'] == 'NULL' || $v_l_msg['timesheet']['day_20'] == '0') {
                    $day_20 = $this->input->post('day_20');
                } else {
                    $day_20 = $v_l_msg['timesheet']['day_20'];
                }
                //for day_21
                if ($v_l_msg['timesheet']['day_21'] == 'NULL' || $v_l_msg['timesheet']['day_21'] == '0') {
                    $day_21 = $this->input->post('day_21');
                } else {
                    $day_21 = $v_l_msg['timesheet']['day_21'];
                }
                //for day_22
                if ($v_l_msg['timesheet']['day_22'] == 'NULL' || $v_l_msg['timesheet']['day_22'] == '0') {
                    $day_22 = $this->input->post('day_22');
                } else {
                    $day_22 = $v_l_msg['timesheet']['day_22'];
                }
                //for day_23
                if ($v_l_msg['timesheet']['day_23'] == 'NULL' || $v_l_msg['timesheet']['day_23'] == '0') {
                    $day_23 = $this->input->post('day_23');
                } else {
                    $day_23 = $v_l_msg['timesheet']['day_23'];
                }
                 //for day_24
                if ($v_l_msg['timesheet']['day_24'] == 'NULL' || $v_l_msg['timesheet']['day_24'] == '0') {
                    $day_24 = $this->input->post('day_24');
                } else {
                    $day_24 = $v_l_msg['timesheet']['day_24'];
                }
                 //for day_25
                if ($v_l_msg['timesheet']['day_25'] == 'NULL' || $v_l_msg['timesheet']['day_25'] == '0') {
                    $day_25 = $this->input->post('day_25');
                } else {
                    $day_25 = $v_l_msg['timesheet']['day_25'];
                }
                //for day_26
                if ($v_l_msg['timesheet']['day_26'] == 'NULL' || $v_l_msg['timesheet']['day_26'] == '0') {
                    $day_26 = $this->input->post('day_26');
                } else {
                    $day_26 = $v_l_msg['timesheet']['day_26'];
                }
                //for day_27
                if ($v_l_msg['timesheet']['day_27'] == 'NULL' || $v_l_msg['timesheet']['day_27'] == '0') {
                    $day_27 = $this->input->post('day_27');
                } else {
                    $day_27 = $v_l_msg['timesheet']['day_27'];
                }
                 //for day_28
                if ($v_l_msg['timesheet']['day_28'] == 'NULL' || $v_l_msg['timesheet']['day_28'] == '0') {
                    $day_28 = $this->input->post('day_28');
                } else {
                    $day_28 = $v_l_msg['timesheet']['day_28'];
                }
                 //for day_29
                if ($v_l_msg['timesheet']['day_29'] == 'NULL' || $v_l_msg['timesheet']['day_29'] == '0') {
                    $day_29 = $this->input->post('day_29');
                } else {
                    $day_29 = $v_l_msg['timesheet']['day_29'];
                }
                 //for day_30
                if ($v_l_msg['timesheet']['day_30'] == 'NULL' || $v_l_msg['timesheet']['day_30'] == '0') {
                    $day_30 = $this->input->post('day_30');
                } else {
                    $day_30 = $v_l_msg['timesheet']['day_30'];
                }
                //for day_31
                if ($v_l_msg['timesheet']['day_31'] == 'NULL' || $v_l_msg['timesheet']['day_31'] == '0') {
                    $day_31 = $this->input->post('day_31');
                } else {
                    $day_31 = $v_l_msg['timesheet']['day_31'];
                }
                //for total of all days
                if (isset($v_l_msg['timesheet']['total']) && $v_l_msg['timesheet']['total'] != '') {
                    $total = $day_1+$day_2+$day_3+$day_4+$day_5+$day_6+$day_7+$day_8+$day_9+$day_10+$day_11+$day_12+$day_13+$day_14+$day_15+$day_16+$day_17+$day_18+$day_19+$day_20+$day_21+$day_22+$day_23+$day_24+$day_25+$day_26+$day_27+$day_28+$day_29+$day_30+$day_31;
                } else {
                    $total = 0;
                }
                $v_l_for_array = array(
                    'day_1' => $day_1,
                    'day_2' => $day_2,
                    'day_3' => $day_3,
                    'day_4' => $day_4,
                    'day_5' => $day_5,
                    'day_6' => $day_6,
                    'day_7' => $day_7,
                    'day_8' => $day_8,
                    'day_9' => $day_9,
                    'day_10' => $day_10,
                    'day_11' => $day_11,
                    'day_12' => $day_12,
                    'day_13' => $day_13,
                    'day_14' => $day_14,
                    'day_15' => $day_15,
                    'day_16' => $day_16,
                    'day_17' => $day_17,
                    'day_18' => $day_18,
                    'day_19' => $day_19,
                    'day_20' => $day_20,
                    'day_21' => $day_21,
                    'day_22' => $day_22,
                    'day_23' => $day_23,
                    'day_24' => $day_24,
                    'day_25' => $day_25,
                    'day_26' => $day_26,
                    'day_27' => $day_27,
                    'day_28' => $day_28,
                    'day_29' => $day_29,
                    'day_30' => $day_30,
                    'day_31' => $day_31,
                    'total' => $total
                );  